#[START hello]
print("Hello")
#[END lol]
